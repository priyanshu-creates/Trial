
// Utility to parse speech into structured form data
interface FormData {
  title?: string;
  description?: string;
  price?: string;
  quantity?: string;
  seller?: string;
  location?: string;
}

/**
 * Parses speech text to extract form field values
 */
export function parseSpeechToFormData(speech: string): FormData {
  console.log("Parsing speech:", speech);
  const data: FormData = {};
  const lowercaseSpeech = speech.toLowerCase();
  
  // Extract title
  const titleMatch = lowercaseSpeech.match(/title(?:\sis|\:|\s(?:is|should be|will be))?\s(.+?)(?:\.|and|,|\s(?:description|price|quantity|seller|location)|\s*$)/i);
  if (titleMatch && titleMatch[1]) {
    data.title = titleMatch[1].trim();
    console.log("Extracted title:", data.title);
  }
  
  // Extract description
  const descriptionMatch = lowercaseSpeech.match(/description(?:\sis|\:|\s(?:is|should be|will be))?\s(.+?)(?:\.|and|,|\s(?:title|price|quantity|seller|location)|\s*$)/i);
  if (descriptionMatch && descriptionMatch[1]) {
    data.description = descriptionMatch[1].trim();
    console.log("Extracted description:", data.description);
  }
  
  // Extract price
  const priceMatch = lowercaseSpeech.match(/price(?:\sis|\:|\s(?:is|should be|will be))?\s(.+?)(?:\.|and|,|\s(?:title|description|quantity|seller|location)|\s*$)/i);
  if (priceMatch && priceMatch[1]) {
    // Extract numeric values and currency symbols
    const priceText = priceMatch[1].trim();
    const numericMatch = priceText.match(/(\$?\d+(?:\.\d+)?)/);
    data.price = numericMatch ? numericMatch[0] : priceText;
    console.log("Extracted price:", data.price);
  }
  
  // Extract quantity
  const quantityMatch = lowercaseSpeech.match(/quantity(?:\sis|\:|\s(?:is|should be|will be))?\s(.+?)(?:\.|and|,|\s(?:title|description|price|seller|location)|\s*$)/i);
  if (quantityMatch && quantityMatch[1]) {
    // Extract numeric values
    const quantityText = quantityMatch[1].trim();
    const numericMatch = quantityText.match(/(\d+)/);
    data.quantity = numericMatch ? numericMatch[0] : quantityText;
    console.log("Extracted quantity:", data.quantity);
  }
  
  // Extract seller
  const sellerMatch = lowercaseSpeech.match(/seller(?:\sis|\:|\s(?:is|should be|will be))?\s(.+?)(?:\.|and|,|\s(?:title|description|price|quantity|location)|\s*$)/i);
  if (sellerMatch && sellerMatch[1]) {
    data.seller = sellerMatch[1].trim();
    console.log("Extracted seller:", data.seller);
  }
  
  // Extract location
  const locationMatch = lowercaseSpeech.match(/location(?:\sis|\:|\s(?:is|should be|will be))?\s(.+?)(?:\.|and|,|\s(?:title|description|price|quantity|seller)|\s*$)/i);
  if (locationMatch && locationMatch[1]) {
    data.location = locationMatch[1].trim();
    console.log("Extracted location:", data.location);
  }
  
  // Fallback strategy: look for direct field mentions without specific patterns
  if (Object.keys(data).length === 0) {
    console.log("Using fallback extraction method");
    const sentences = speech.split(/[.!?]+/);
    
    for (const sentence of sentences) {
      if (sentence.toLowerCase().includes('title')) {
        const parts = sentence.split(/title\s*(?:is|:)/i);
        if (parts.length > 1 && parts[1].trim()) {
          data.title = parts[1].trim();
          console.log("Fallback extracted title:", data.title);
        }
      }
      if (sentence.toLowerCase().includes('description')) {
        const parts = sentence.split(/description\s*(?:is|:)/i);
        if (parts.length > 1 && parts[1].trim()) {
          data.description = parts[1].trim();
          console.log("Fallback extracted description:", data.description);
        }
      }
      if (sentence.toLowerCase().includes('price')) {
        const parts = sentence.split(/price\s*(?:is|:)/i);
        if (parts.length > 1 && parts[1].trim()) {
          data.price = parts[1].trim();
          console.log("Fallback extracted price:", data.price);
        }
      }
      if (sentence.toLowerCase().includes('quantity')) {
        const parts = sentence.split(/quantity\s*(?:is|:)/i);
        if (parts.length > 1 && parts[1].trim()) {
          data.quantity = parts[1].trim();
          console.log("Fallback extracted quantity:", data.quantity);
        }
      }
      if (sentence.toLowerCase().includes('seller')) {
        const parts = sentence.split(/seller\s*(?:is|:)/i);
        if (parts.length > 1 && parts[1].trim()) {
          data.seller = parts[1].trim();
          console.log("Fallback extracted seller:", data.seller);
        }
      }
      if (sentence.toLowerCase().includes('location')) {
        const parts = sentence.split(/location\s*(?:is|:)/i);
        if (parts.length > 1 && parts[1].trim()) {
          data.location = parts[1].trim();
          console.log("Fallback extracted location:", data.location);
        }
      }
    }
  }
  
  console.log("Final extracted data:", data);
  return data;
}
