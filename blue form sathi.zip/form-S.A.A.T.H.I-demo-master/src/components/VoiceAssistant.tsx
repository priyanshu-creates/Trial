
import { useState, useEffect, useCallback } from "react";
import { Button } from "@/components/ui/button";
import { Mic, MicOff, Volume } from "lucide-react";
import { parseSpeechToFormData } from "@/utils/speechParser";
import { useToast } from "@/hooks/use-toast";

// Define our form structure
export interface FormData {
  title: string;
  description: string;
  price: string;
  quantity: string;
  seller: string;
  location: string;
}

// Define props
interface VoiceAssistantProps {
  onResultsProcessed: (data: Partial<FormData>, active?: string) => void;
  isListening: boolean;
  setIsListening: (listening: boolean) => void;
}

// Init SpeechRecognition with fallback
// Using 'any' here to avoid TypeScript errors since the Web Speech API types aren't included by default
const SpeechRecognitionAPI = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

const VoiceAssistant: React.FC<VoiceAssistantProps> = ({ 
  onResultsProcessed, 
  isListening, 
  setIsListening 
}) => {
  const [transcript, setTranscript] = useState("");
  const [confidence, setConfidence] = useState(0);
  const [recognition, setRecognition] = useState<any>(null);
  const [isAvailable, setIsAvailable] = useState(true);
  const [currentField, setCurrentField] = useState<string | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const { toast } = useToast();

  // Initialize speech recognition
  useEffect(() => {
    if (!SpeechRecognitionAPI) {
      setIsAvailable(false);
      toast({
        variant: "destructive",
        title: "Speech recognition not supported",
        description: "Your browser doesn't support speech recognition. Try Chrome or Edge."
      });
      return;
    }

    const recognitionInstance = new SpeechRecognitionAPI();
    recognitionInstance.continuous = true;
    recognitionInstance.interimResults = true;
    recognitionInstance.lang = 'en-US';
    
    recognitionInstance.onresult = (event: any) => {
      const current = event.resultIndex;
      const result = event.results[current];
      const transcriptValue = result[0].transcript;
      
      console.log("Speech recognized:", transcriptValue);
      setTranscript(transcriptValue);
      setConfidence(result[0].confidence);
      
      // Process results if they are final
      if (result.isFinal) {
        console.log("Processing final result:", transcriptValue);
        processResults(transcriptValue);
      }
    };

    recognitionInstance.onerror = (event: any) => {
      console.error("Speech recognition error", event.error);
      if (event.error === 'not-allowed') {
        toast({
          variant: "destructive",
          title: "Microphone access denied",
          description: "Please allow microphone access to use voice features."
        });
        setIsListening(false);
      }
    };

    recognitionInstance.onend = () => {
      console.log("Speech recognition ended, isListening:", isListening);
      if (isListening) {
        // Restart if we're supposed to be listening but it ended
        try {
          recognitionInstance.start();
          console.log("Restarted speech recognition");
        } catch (error) {
          console.error("Failed to restart recognition:", error);
        }
      }
    };

    setRecognition(recognitionInstance);

    return () => {
      recognitionInstance.onresult = null;
      recognitionInstance.onend = null;
      recognitionInstance.onerror = null;
      if (recognitionInstance) {
        recognitionInstance.abort();
      }
    };
  }, [isListening, toast, setIsListening]);

  // Start or stop listening when isListening changes
  useEffect(() => {
    if (!recognition) return;
    
    if (isListening) {
      try {
        recognition.start();
        console.log("Started speech recognition");
      } catch (error) {
        console.error("Error starting recognition:", error);
      }
    } else {
      try {
        recognition.stop();
        console.log("Stopped speech recognition");
      } catch (error) {
        console.error("Error stopping recognition:", error);
      }
    }
  }, [isListening, recognition]);

  // Handle toggling the listening state
  const toggleListening = useCallback(() => {
    if (!recognition) return;
    
    const newListeningState = !isListening;
    setIsListening(newListeningState);
    
    if (newListeningState) {
      toast({
        title: "Listening...",
        description: "Speak to fill out the form. Mention field names like 'title' or 'price'."
      });
    } else {
      toast({
        title: "Stopped listening",
      });
    }
  }, [isListening, recognition, toast, setIsListening]);

  // Process speech results
  const processResults = useCallback((text: string) => {
    setIsProcessing(true);
    
    // Small delay to show processing state
    setTimeout(() => {
      try {
        const data = parseSpeechToFormData(text);
        console.log("Parsed speech data:", data);
        
        let detectedField: string | null = null;
        
        // Determine which field was likely mentioned
        const fields = ["title", "description", "price", "quantity", "seller", "location"];
        
        for (const field of fields) {
          if (text.toLowerCase().includes(field.toLowerCase())) {
            detectedField = field;
            break;
          }
        }
        
        setCurrentField(detectedField);
        
        // Only call if we have data to update
        if (Object.keys(data).length > 0) {
          onResultsProcessed(data, detectedField || undefined);
          
          toast({
            title: `Updated form data`,
            description: `Detected: ${Object.keys(data).join(', ')}`,
            variant: "default",
          });
        }
      } catch (error) {
        console.error("Error processing speech results:", error);
        toast({
          variant: "destructive",
          title: "Processing error",
          description: "Failed to process your speech. Please try again."
        });
      } finally {
        setIsProcessing(false);
      }
    }, 300);
  }, [onResultsProcessed, toast]);

  if (!isAvailable) {
    return (
      <div className="bg-red-50 p-4 rounded-lg border border-red-200 mb-6">
        <h3 className="text-red-600 font-medium">Speech Recognition Not Available</h3>
        <p className="text-sm text-red-500">
          Your browser doesn't support speech recognition. Please try Chrome, Edge, or Safari.
        </p>
      </div>
    );
  }

  return (
    <div className="mb-6">
      <div className="flex items-center justify-between mb-4 bg-white p-4 rounded-lg border border-gray-200 shadow-sm">
        <div className="flex-1">
          <h3 className="font-medium text-gray-800">
            {isListening ? (
              <span className="flex items-center text-blue-600">
                <Volume className="animate-pulse mr-2 h-5 w-5" />
                Listening...
              </span>
            ) : (
              "Voice Assistant"
            )}
          </h3>
          <p className="text-sm text-gray-500 mt-1">
            {isListening 
              ? "Say things like 'Title is leather jacket' or 'Price is 50 dollars'"
              : "Press the microphone button and speak to fill the form"}
          </p>
        </div>
        <Button 
          onClick={toggleListening}
          variant={isListening ? "destructive" : "default"}
          size="icon"
          className={`h-14 w-14 rounded-full ${isListening ? "bg-red-500 hover:bg-red-600" : "bg-blue-500 hover:bg-blue-600"} transition-all duration-200 shadow-md`}
        >
          {isListening ? (
            <MicOff className="h-6 w-6 text-white" />
          ) : (
            <Mic className="h-6 w-6 text-white" />
          )}
        </Button>
      </div>
      
      {(isListening && transcript) && (
        <div className="bg-blue-50 p-3 rounded-lg border border-blue-100 mb-4">
          <p className="text-sm font-medium text-blue-800">I heard:</p>
          <p className="text-gray-700">{transcript}</p>
          {isProcessing ? (
            <div className="flex items-center space-x-2 mt-2">
              <div className="h-1.5 w-1.5 bg-blue-600 rounded-full animate-pulse"></div>
              <div className="h-1.5 w-1.5 bg-blue-600 rounded-full animate-pulse delay-150"></div>
              <div className="h-1.5 w-1.5 bg-blue-600 rounded-full animate-pulse delay-300"></div>
              <span className="text-xs text-blue-600">Processing...</span>
            </div>
          ) : currentField && (
            <p className="text-xs text-blue-600 mt-2">
              Detected field: <span className="font-semibold">{currentField}</span>
            </p>
          )}
        </div>
      )}
    </div>
  );
};

export default VoiceAssistant;
