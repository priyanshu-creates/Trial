
import React from "react";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { cn } from "@/lib/utils";

interface FormFieldProps {
  id: string;
  label: string;
  value: string;
  onChange: (value: string) => void;
  type?: "text" | "number" | "textarea" | "price";
  placeholder?: string;
  active?: boolean;
}

const FormField: React.FC<FormFieldProps> = ({
  id,
  label,
  value,
  onChange,
  type = "text",
  placeholder = "",
  active = false,
}) => {
  return (
    <div className={cn("mb-4 transition-all duration-300", 
      active ? "scale-[1.02] bg-blue-50 p-3 rounded-lg border border-blue-300 shadow-md" : ""
    )}>
      <Label 
        htmlFor={id} 
        className={cn("block mb-2 font-medium", 
          active ? "text-blue-600" : "text-gray-700"
        )}
      >
        {label}
      </Label>
      
      {type === "textarea" ? (
        <Textarea
          id={id}
          value={value}
          onChange={(e) => onChange(e.target.value)}
          placeholder={placeholder}
          className={cn(
            "w-full", 
            active ? "border-blue-400 ring-2 ring-blue-100" : ""
          )}
        />
      ) : type === "price" ? (
        <div className="relative">
          <span className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500">$</span>
          <Input
            id={id}
            type="text"
            value={value}
            onChange={(e) => onChange(e.target.value)}
            placeholder={placeholder}
            className={cn(
              "pl-7", 
              active ? "border-blue-400 ring-2 ring-blue-100" : ""
            )}
          />
        </div>
      ) : (
        <Input
          id={id}
          type={type}
          value={value}
          onChange={(e) => onChange(e.target.value)}
          placeholder={placeholder}
          className={cn(
            active ? "border-blue-400 ring-2 ring-blue-100" : ""
          )}
        />
      )}
    </div>
  );
};

export default FormField;
