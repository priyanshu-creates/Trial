
import { useState, useEffect } from "react";
import { useToast } from "@/components/ui/use-toast";
import { Button } from "@/components/ui/button";
import FormField from "@/components/FormField";
import VoiceAssistant, { FormData } from "@/components/VoiceAssistant";
import Header from "@/components/Header";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";

const Index = () => {
  // Form state
  const [formData, setFormData] = useState<FormData>({
    title: "",
    description: "",
    price: "",
    quantity: "",
    seller: "",
    location: "",
  });
  
  // State tracking
  const [isListening, setIsListening] = useState(false);
  const [activeField, setActiveField] = useState<string | undefined>(undefined);
  const { toast } = useToast();
  const [browserSupported, setBrowserSupported] = useState<boolean | null>(null);
  
  // Check browser support for SpeechRecognition
  useEffect(() => {
    // Using 'any' here to avoid TypeScript errors since the Web Speech API types aren't included by default
    const SpeechRecognitionAPI = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    const isSupported = !!SpeechRecognitionAPI;
    setBrowserSupported(isSupported);
    
    if (!isSupported) {
      toast({
        variant: "destructive",
        title: "Browser not supported",
        description: "Your browser doesn't support speech recognition. Please try Chrome, Edge, or Safari.",
      });
    }
  }, [toast]);
  
  // Handle field value updates
  const handleFieldChange = (field: keyof FormData, value: string) => {
    setFormData(prev => ({
      ...prev,
      [field]: value,
    }));
  };
  
  // Handle incoming voice data
  const handleVoiceResults = (data: Partial<FormData>, activeFieldKey?: string) => {
    // Update form data with any fields that were detected
    const newFormData = { ...formData };
    let updatedFields = 0;
    let updatedFieldNames: string[] = [];
    
    Object.entries(data).forEach(([key, value]) => {
      if (value && key in formData) {
        newFormData[key as keyof FormData] = value;
        updatedFields++;
        updatedFieldNames.push(key);
      }
    });
    
    if (updatedFields > 0) {
      setFormData(newFormData);
      toast({
        title: `Updated ${updatedFields} field${updatedFields > 1 ? 's' : ''}`,
        description: updatedFieldNames.join(', '),
        variant: "default",
      });
    }
    
    // Update active field highlight
    setActiveField(activeFieldKey);
    
    // Auto clear the active field highlight after 3 seconds
    setTimeout(() => {
      setActiveField(undefined);
    }, 3000);
  };
  
  // Handle form submission
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Validate form
    const requiredFields: (keyof FormData)[] = ["title", "price"];
    const missingFields = requiredFields.filter(field => !formData[field]);
    
    if (missingFields.length > 0) {
      toast({
        variant: "destructive",
        title: "Missing required fields",
        description: `Please fill out: ${missingFields.join(", ")}`,
      });
      return;
    }
    
    // Form is valid - would normally submit to backend
    toast({
      title: "Form submitted!",
      description: "Your form data has been processed successfully.",
    });
    
    console.log("Form data:", formData);
    
    // Reset form
    setFormData({
      title: "",
      description: "",
      price: "",
      quantity: "",
      seller: "",
      location: "",
    });
  };
  
  // Handle form reset
  const handleReset = () => {
    setFormData({
      title: "",
      description: "",
      price: "",
      quantity: "",
      seller: "",
      location: "",
    });
    
    toast({
      title: "Form reset",
      description: "All fields have been cleared",
    });
  };
  
  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <main className="container mx-auto px-4 pb-12">
        <Card className="max-w-2xl mx-auto">
          <CardHeader>
            <CardTitle className="text-xl font-semibold text-gray-800">Product Form</CardTitle>
          </CardHeader>
          
          <CardContent>
            {browserSupported !== false && (
              <VoiceAssistant 
                onResultsProcessed={handleVoiceResults}
                isListening={isListening}
                setIsListening={setIsListening}
              />
            )}
            
            <form onSubmit={handleSubmit}>
              <FormField
                id="title"
                label="Title *"
                value={formData.title}
                onChange={(value) => handleFieldChange("title", value)}
                placeholder="Enter product title"
                active={activeField === "title"}
              />
              
              <FormField
                id="description"
                label="Description"
                value={formData.description}
                onChange={(value) => handleFieldChange("description", value)}
                placeholder="Enter product description"
                type="textarea"
                active={activeField === "description"}
              />
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <FormField
                  id="price"
                  label="Price *"
                  value={formData.price}
                  onChange={(value) => handleFieldChange("price", value)}
                  placeholder="0.00"
                  type="price"
                  active={activeField === "price"}
                />
                
                <FormField
                  id="quantity"
                  label="Quantity"
                  value={formData.quantity}
                  onChange={(value) => handleFieldChange("quantity", value)}
                  placeholder="Enter quantity"
                  type="number"
                  active={activeField === "quantity"}
                />
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <FormField
                  id="seller"
                  label="Seller"
                  value={formData.seller}
                  onChange={(value) => handleFieldChange("seller", value)}
                  placeholder="Enter seller name"
                  active={activeField === "seller"}
                />
                
                <FormField
                  id="location"
                  label="Location"
                  value={formData.location}
                  onChange={(value) => handleFieldChange("location", value)}
                  placeholder="Enter location"
                  active={activeField === "location"}
                />
              </div>
            </form>
          </CardContent>
          
          <CardFooter className="flex justify-between border-t border-gray-100 pt-4">
            <Button 
              variant="outline" 
              onClick={handleReset}
              className="border-gray-300"
            >
              Reset
            </Button>
            <Button 
              onClick={handleSubmit}
              className="bg-blue-600 hover:bg-blue-700"
            >
              Submit
            </Button>
          </CardFooter>
        </Card>
        
        <div className="mt-8 max-w-2xl mx-auto bg-white p-4 rounded-lg border border-gray-200 shadow-sm">
          <h3 className="text-lg font-medium text-gray-800 mb-2">How to use the voice assistant:</h3>
          <ol className="list-decimal pl-5 space-y-2 text-gray-600">
            <li>Click the microphone button to start recording</li>
            <li>Say phrases like <span className="font-medium text-blue-600">"Title is leather jacket"</span> or <span className="font-medium text-blue-600">"The price is 50 dollars"</span></li>
            <li>You can also try phrases like <span className="font-medium text-blue-600">"Quantity should be 5"</span> or <span className="font-medium text-blue-600">"The location is New York"</span></li>
            <li>Try a combined sentence: <span className="font-medium text-blue-600">"The title is vintage camera, price is $75, and seller is John Smith"</span></li>
            <li>The form will automatically update with recognized values</li>
            <li>You can manually edit any fields as needed</li>
          </ol>
        </div>
      </main>
    </div>
  );
};

export default Index;
