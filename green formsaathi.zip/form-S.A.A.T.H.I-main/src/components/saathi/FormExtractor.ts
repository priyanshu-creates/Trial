
import { FormData, FormExtractorProps } from './types';

export const extractFormData = ({ text, detectedLanguage, currentFormData }: FormExtractorProps): FormData => {
  const newFormData = { ...currentFormData };
  
  const getLanguagePatterns = (langCode: string) => {
    let patterns = {
      title: [
        /(?:title(?:\s+is|\s*:)?\s+)([^,\.]+)/i,
        /(?:name(?:\s+is|\s*:)?\s+)([^,\.]+)/i,
        /([^,\.]{3,30})/
      ],
      description: [
        /(?:description(?:\s+is|\s*:)?\s+)(.+?)(?=\s+price|\s+quantity|\s+seller|\s+location|$)/i,
        /(?:about(?:\s+is|\s*:)?\s+)([^.!?]+[.!?]?\s*(?:[^.!?]+[.!?]?\s*){0,3})/i
      ],
      price: [
        /(?:price(?:\s+is|\s*:)?\s+)([\$₹€£¥]?\d+(?:\.\d{1,2})?)/i,
        /(?:costs?(?:\s+is|\s*:)?\s+)([\$₹€£¥]?\d+(?:\.\d{1,2})?)/i,
        /([\$₹€£¥]?\d+(?:\.\d{1,2})?)/
      ],
      quantity: [
        /(?:quantity(?:\s+is|\s*:)?\s+)(\d+)/i,
        /(?:amount(?:\s+is|\s*:)?\s+)(\d+)/i,
        /(\d+)(?:\s+items?|\s+pieces?|\s+units?)?/i
      ],
      seller: [
        /(?:seller(?:\s+is|\s*:)?\s+)([^,\.]+)/i,
        /(?:(?:sold|made|produced)(?:\s+by)?\s+)([^,\.]+)/i,
        /(?:vendor(?:\s+is|\s*:)?\s+)([^,\.]+)/i
      ],
      location: [
        /(?:location(?:\s+is|\s*:)?\s+)([^,\.]+)/i,
        /(?:(?:in|at|from)(?:\s+the)?\s+)([^,\.]+)/i,
        /(?:place(?:\s+is|\s*:)?\s+)([^,\.]+)/i
      ]
    };

    if (langCode.startsWith('hi')) {
      patterns = {
        title: [
          /(?:शीर्षक(?:\s+है|\s*:)?\s+)([^,।]+)/i,
          /(?:नाम(?:\s+है|\s*:)?\s+)([^,।]+)/i,
          /([^,।]{3,30})/
        ],
        description: [
          /(?:विवरण(?:\s+है|\s*:)?\s+)([^।]+)/i,
          /(?:के बारे में(?:\s+है|\s*:)?\s+)([^।]+)/i
        ],
        price: [
          /(?:कीमत(?:\s+है|\s*:)?\s+)([₹]?\d+(?:\.\d{1,2})?)/i,
          /(?:मूल्य(?:\s+है|\s*:)?\s+)([₹]?\d+(?:\.\d{1,2})?)/i,
          /([₹]?\d+(?:\.\d{1,2})?)/
        ],
        quantity: [
          /(?:मात्रा(?:\s+है|\s*:)?\s+)(\d+)/i,
          /(?:संख्या(?:\s+है|\s*:)?\s+)(\d+)/i,
          /(\d+)(?:\s+इकाई|\s+नग)?/i
        ],
        seller: [
          /(?:विक्रेता(?:\s+है|\s*:)?\s+)([^,।]+)/i,
          /(?:(?:बेचा|बनाया|उत्पादित)(?:\s+किया)?\s+)([^,।]+)/i
        ],
        location: [
          /(?:स्थान(?:\s+है|\s*:)?\s+)([^,।]+)/i,
          /(?:(?:में|पर|से)(?:\s+से)?\s+)([^,।]+)/i
        ]
      };
    } else if (langCode.startsWith('bn')) {
      patterns = {
        title: [
          /(?:শিরোনাম(?:\s+হল|\s*:)?\s+)([^,।]+)/i,
          /(?:নাম(?:\s+হল|\s*:)?\s+)([^,।]+)/i,
          /([^,।]{3,30})/
        ],
        description: [
          /(?:বিবরণ(?:\s+হল|\s*:)?\s+)([^।]+)/i,
          /(?:সম্পর্কে(?:\s+হল|\s*:)?\s+)([^।]+)/i
        ],
        price: [
          /(?:দাম(?:\s+হল|\s*:)?\s+)([₹]?\d+(?:\.\d{1,2})?)/i,
          /(?:মূল্য(?:\s+হল|\s*:)?\s+)([₹]?\d+(?:\.\d{1,2})?)/i,
          /([₹]?\d+(?:\.\d{1,2})?)/
        ],
        quantity: [
          /(?:পরিমাণ(?:\s+হল|\s*:)?\s+)(\d+)/i,
          /(?:সংখ্যা(?:\s+হল|\s*:)?\s+)(\d+)/i,
          /(\d+)(?:\s+টি|\s+পিস)?/i
        ],
        seller: [
          /(?:বিক্রেতা(?:\s+হল|\s*:)?\s+)([^,।]+)/i,
          /(?:(?:বিক্রি|তৈরি|উৎপাদন)(?:\s+করেছে)?\s+)([^,।]+)/i
        ],
        location: [
          /(?:স্থান(?:\s+হল|\s*:)?\s+)([^,।]+)/i,
          /(?:(?:এ|থেকে|য়)(?:\s+থেকে)?\s+)([^,।]+)/i
        ]
      };
    }
    // Add more language patterns as needed
    
    return patterns;
  };

  const patterns = getLanguagePatterns(detectedLanguage);
  
  // Process the text for title last, as it might be a fallback
  let workingText = text;
  
  // Extract specific fields first
  const extractField = (field: keyof FormData, fieldPatterns: RegExp[]) => {
    for (const pattern of fieldPatterns) {
      const match = workingText.match(pattern);
      if (match && match[1]) {
        newFormData[field] = match[1].trim();
        // Remove the matched text to prevent re-matching
        workingText = workingText.replace(match[0], '');
        return true;
      }
    }
    return false;
  };

  // Extract fields in order of specificity
  extractField('price', patterns.price);
  extractField('quantity', patterns.quantity);
  extractField('seller', patterns.seller);
  extractField('location', patterns.location);
  extractField('description', patterns.description);
  
  // If no title was found and we have remaining text, use it as title
  if (!newFormData.title && workingText.trim().length > 0) {
    const firstLine = workingText.split(/[।,.!?\n]/)[0].trim();
    if (firstLine.length > 0 && firstLine.length < 100) {
      newFormData.title = firstLine;
    }
  }
  
  return newFormData;
};
