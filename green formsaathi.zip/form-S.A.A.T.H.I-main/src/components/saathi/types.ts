
export interface FormData {
  title: string;
  description: string;
  price: string;
  quantity: string;
  seller: string;
  location: string;
}

export interface FormExtractorProps {
  text: string;
  detectedLanguage: string;
  currentFormData: FormData;
}
