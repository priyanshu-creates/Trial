
import React from 'react';
import { Button } from "@/components/ui/button";
import { Mic, MicOff } from "lucide-react";
import AnimatedPulse from '../AnimatedPulse';

interface VoiceRecognitionButtonProps {
  isListening: boolean;
  isModelLoading: boolean;
  onStartListening: () => void;
  onStopListening: () => void;
}

const VoiceRecognitionButton: React.FC<VoiceRecognitionButtonProps> = ({
  isListening,
  isModelLoading,
  onStartListening,
  onStopListening
}) => {
  return (
    <div className="mb-6 flex justify-center relative">
      <AnimatedPulse isActive={isListening} />
      <Button 
        onClick={isListening ? onStopListening : onStartListening}
        disabled={isModelLoading}
        variant={isListening ? "destructive" : "default"}
        size="lg"
        className={`rounded-full w-16 h-16 flex items-center justify-center transition-all z-10 ${
          isListening ? 'shadow-lg shadow-primary/25' : ''
        }`}
        style={{ backgroundColor: '#6B8E23' }}
      >
        {isListening ? 
          <MicOff size={24} style={{ color: '#FFFFFF' }} /> : 
          <Mic size={24} style={{ color: '#FFFFFF' }} />
        }
      </Button>
    </div>
  );
};

export default VoiceRecognitionButton;
