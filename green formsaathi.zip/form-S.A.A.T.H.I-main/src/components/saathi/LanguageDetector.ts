
import { SUPPORTED_LANGUAGES } from './constants';

export const detectLanguage = async (text: string): Promise<string> => {
  if (!text || text.trim().length === 0) {
    return 'en-US';
  }
  
  try {
    const languages = [
      { 
        code: 'en-US', 
        alphabet: /[a-zA-Z]/,
        words: ['the', 'and', 'is', 'in', 'a', 'to', 'it', 'of', 'for', 'that']
      },
      { 
        code: 'hi-IN',
        alphabet: /[\u0900-\u097F]/,
        words: ['और', 'है', 'का', 'की', 'एक', 'में', 'से', 'को', 'पर', 'यह']
      },
      { 
        code: 'bn-IN',
        alphabet: /[\u0980-\u09FF]/,
        words: ['এবং', 'একটি', 'আছে', 'করা', 'হয়', 'কি', 'এই', 'সে', 'তার']
      },
      {
        code: 'te-IN',
        alphabet: /[\u0C00-\u0C7F]/,
        words: ['మరియు', 'ఉంది', 'లో', 'కి', 'నుండి', 'చేయండి', 'వారు']
      },
      {
        code: 'mr-IN',
        alphabet: /[\u0900-\u097F]/,
        words: ['आणि', 'आहे', 'ते', 'या', 'एक', 'मध्ये', 'करा']
      },
      {
        code: 'ta-IN',
        alphabet: /[\u0B80-\u0BFF]/,
        words: ['மற்றும்', 'என்று', 'அது', 'இந்த', 'ஒரு', 'செய்']
      },
      {
        code: 'pa-IN',
        alphabet: /[\u0A00-\u0A7F]/,
        words: ['ਅਤੇ', 'ਹੈ', 'ਦਾ', 'ਇਹ', 'ਇੱਕ', 'ਵਿੱਚ', 'ਕਰੋ']
      },
      {
        code: 'gu-IN',
        alphabet: /[\u0A80-\u0AFF]/,
        words: ['અને', 'છે', 'એક', 'માં', 'કરો', 'તે', 'આ']
      },
      {
        code: 'kn-IN',
        alphabet: /[\u0C80-\u0CFF]/,
        words: ['ಮತ್ತು', 'ಇದೆ', 'ಒಂದು', 'ಮಾಡಿ', 'ಅವರು']
      },
      {
        code: 'or-IN',
        alphabet: /[\u0B00-\u0B7F]/,
        words: ['ଏବଂ', 'ଅଛି', 'ର', 'ଏହି', 'ଏକ', 'କରନ୍ତୁ']
      },
      {
        code: 'ml-IN',
        alphabet: /[\u0D00-\u0D7F]/,
        words: ['കൂടാതെ', 'ആണ്', 'ഒരു', 'ചെയ്യുക']
      },
      {
        code: 'ur-IN',
        alphabet: /[\u0600-\u06FF]/,
        words: ['اور', 'ہے', 'کا', 'کی', 'ایک', 'میں', 'سے']
      },
      {
        code: 'as-IN',
        alphabet: /[\u0980-\u09FF]/,
        words: ['আৰু', 'হয়', 'এই', 'এটা', 'কৰক', 'তাৰ']
      }
    ];

    const normalizedText = text.toLowerCase();
    
    // Count characters from each language's alphabet
    const charCounts = languages.map(lang => {
      const alphabetMatches = normalizedText.match(new RegExp(lang.alphabet.source, 'g'));
      return { 
        code: lang.code, 
        count: alphabetMatches ? alphabetMatches.length : 0 
      };
    });
    
    // Log character counts for debugging
    console.log('Character counts by language:', charCounts);
    
    // Calculate scores based on character presence and word matches
    const scores = languages.map(lang => {
      let score = 0;
      
      // Check for characters from this language's alphabet
      const alphabetMatches = normalizedText.match(new RegExp(lang.alphabet.source, 'g'));
      if (alphabetMatches) {
        const alphabetCharCount = alphabetMatches.length;
        const textLength = normalizedText.replace(/\s/g, '').length;
        if (textLength > 0) {
          score += (alphabetCharCount / textLength) * 80; // High weight for alphabet matches
        }
      }
      
      // Check for words from this language
      const words = normalizedText.split(/\s+/);
      words.forEach(word => {
        if (lang.words.includes(word)) {
          score += 15; // Increased weight for word matches
        }
      });
      
      return { code: lang.code, score };
    });
    
    scores.sort((a, b) => b.score - a.score);
    console.log('Language detection scores:', scores);
    
    // Return the language with the highest score if it's above the threshold
    if (scores.length > 0 && scores[0].score > 10) {
      return scores[0].code;
    }
    
    return 'en-US'; // Default to English if no clear match
  } catch (error) {
    console.error('Language detection error:', error);
    return 'en-US';
  }
};
