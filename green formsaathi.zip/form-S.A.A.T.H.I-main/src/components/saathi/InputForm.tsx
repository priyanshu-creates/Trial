
import React from 'react';
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { FormData } from './types';
import { SUPPORTED_LANGUAGES } from './constants';

interface InputFormProps {
  formData: FormData;
  onInputChange: (field: keyof FormData, value: string) => void;
  detectedLanguage: string;
  onSubmit: () => void;  // Added missing prop
  onReset: () => void;   // Added missing prop
}

const InputForm: React.FC<InputFormProps> = ({
  formData,
  onInputChange,
  detectedLanguage,
  onSubmit,
  onReset
}) => {
  const labels = SUPPORTED_LANGUAGES.find(lang => lang.code === detectedLanguage)?.labelText || 
                SUPPORTED_LANGUAGES[0].labelText;

  return (
    <div className="space-y-4">
      <div className="grid gap-2">
        <Label htmlFor="title" style={{ color: '#4A5043' }}>
          {labels.title}
        </Label>
        <Input
          id="title"
          value={formData.title}
          onChange={(e) => onInputChange('title', e.target.value)}
          placeholder={labels.title}
          className="border-[#5C7D2B]"
          style={{ color: '#4A5043' }}
        />
      </div>
      
      <div className="grid gap-2">
        <Label htmlFor="description" style={{ color: '#4A5043' }}>
          {labels.description}
        </Label>
        <Textarea
          id="description"
          value={formData.description}
          onChange={(e) => onInputChange('description', e.target.value)}
          placeholder={labels.description}
          className="min-h-[100px] border-[#5C7D2B]"
          style={{ color: '#4A5043' }}
        />
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="grid gap-2">
          <Label htmlFor="price" style={{ color: '#4A5043' }}>
            {labels.price}
          </Label>
          <Input
            id="price"
            value={formData.price}
            onChange={(e) => onInputChange('price', e.target.value)}
            placeholder={labels.price}
            className="border-[#5C7D2B]"
            style={{ color: '#4A5043' }}
          />
        </div>
        <div className="grid gap-2">
          <Label htmlFor="quantity" style={{ color: '#4A5043' }}>
            {labels.quantity}
          </Label>
          <Input
            id="quantity"
            value={formData.quantity}
            onChange={(e) => onInputChange('quantity', e.target.value)}
            placeholder={labels.quantity}
            className="border-[#5C7D2B]"
            style={{ color: '#4A5043' }}
          />
        </div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="grid gap-2">
          <Label htmlFor="seller" style={{ color: '#4A5043' }}>
            {labels.seller}
          </Label>
          <Input
            id="seller"
            value={formData.seller}
            onChange={(e) => onInputChange('seller', e.target.value)}
            placeholder={labels.seller}
            className="border-[#5C7D2B]"
            style={{ color: '#4A5043' }}
          />
        </div>
        <div className="grid gap-2">
          <Label htmlFor="location" style={{ color: '#4A5043' }}>
            {labels.location}
          </Label>
          <Input
            id="location"
            value={formData.location}
            onChange={(e) => onInputChange('location', e.target.value)}
            placeholder={labels.location}
            className="border-[#5C7D2B]"
            style={{ color: '#4A5043' }}
          />
        </div>
      </div>
    </div>
  );
};

export default InputForm;
