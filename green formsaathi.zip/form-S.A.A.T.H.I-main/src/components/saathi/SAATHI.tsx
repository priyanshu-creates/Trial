import React, { useState, useRef, useEffect } from 'react';
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { Volume, Volume2, Languages } from "lucide-react";
import { Button } from "@/components/ui/button";
import { pipeline } from "@huggingface/transformers";
import { FormData } from './types';
import { SUPPORTED_LANGUAGES } from './constants';
import { detectLanguage } from './LanguageDetector';
import { extractFormData } from './FormExtractor';
import VoiceRecognitionButton from './VoiceRecognitionButton';
import InputForm from './InputForm';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"

const SAATHI: React.FC = () => {
  const [isListening, setIsListening] = useState(false);
  const [transcript, setTranscript] = useState('');
  const [detectedLanguage, setDetectedLanguage] = useState('');
  const [processingMessage, setProcessingMessage] = useState('');
  const [formData, setFormData] = useState<FormData>({
    title: '',
    description: '',
    price: '',
    quantity: '',
    seller: '',
    location: '',
  });
  
  const recognitionRef = useRef<SpeechRecognition | null>(null);
  const [isModelLoading, setIsModelLoading] = useState(false);
  const [transcriber, setTranscriber] = useState<any>(null);
  const { toast } = useToast();
  const [selectedLanguage, setSelectedLanguage] = useState('en-US');

  useEffect(() => {
    const loadModel = async () => {
      try {
        setIsModelLoading(true);
        const model = await pipeline("automatic-speech-recognition", "onnx-community/whisper-tiny");
        setTranscriber(model);
      } catch (error) {
        console.error("Failed to load model:", error);
      } finally {
        setIsModelLoading(false);
      }
    };
    
    loadModel();
  }, []);

  const startListening = () => {
    setIsListening(true);
    setProcessingMessage('Listening...');
    
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    
    if (SpeechRecognition) {
      recognitionRef.current = new SpeechRecognition();
      recognitionRef.current.continuous = true;
      recognitionRef.current.interimResults = true;
      recognitionRef.current.lang = selectedLanguage; // Use the selected language for voice input
      
      recognitionRef.current.onstart = () => setIsListening(true);
      
      recognitionRef.current.onresult = async (event: SpeechRecognitionEvent) => {
        const currentTranscript = Array.from(event.results)
          .map(result => result[0].transcript)
          .join(' ');
          
        setTranscript(currentTranscript);
        
        const detectedLang = await detectLanguage(currentTranscript);
        setDetectedLanguage(detectedLang);
      };
      
      recognitionRef.current.onerror = (event: SpeechRecognitionErrorEvent) => {
        console.error('Speech recognition error:', event.error);
        setProcessingMessage('Error: ' + event.error);
        stopListening();
      };
      
      recognitionRef.current.onend = () => {
        if (isListening) {
          processTranscript();
        }
      };
      
      recognitionRef.current.start();
    } else {
      setProcessingMessage('Speech recognition not supported in this browser.');
    }
  };

  const stopListening = () => {
    setIsListening(false);
    if (recognitionRef.current) {
      recognitionRef.current.stop();
      setProcessingMessage('Processing...');
      setTimeout(() => processTranscript(), 500);
    }
  };

  const processTranscript = () => {
    setProcessingMessage('Extracting information...');
    
    const extractedData = extractFormData({
      text: transcript,
      detectedLanguage: detectedLanguage,
      currentFormData: formData
    });

    const updatedFields = Object.entries(extractedData).reduce((acc: string[], [key, value]) => {
      if (value && value !== formData[key as keyof FormData]) {
        acc.push(key);
      }
      return acc;
    }, []);

    setFormData(extractedData);
    
    if (updatedFields.length > 0) {
      const updatedSection = document.getElementById('updated-fields');
      if (updatedSection) {
        updatedSection.scrollIntoView({ behavior: 'smooth' });
      }
    }
    
    setProcessingMessage('');
  };

  const handleInputChange = (field: keyof FormData, value: string) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const handleSubmit = () => {
    const labels = SUPPORTED_LANGUAGES.find(lang => lang.code === detectedLanguage)?.labelText || 
                  SUPPORTED_LANGUAGES[0].labelText;
    
    toast({
      title: labels.submit,
      duration: 3000,
    });
  };

  const resetForm = () => {
    setFormData({
      title: '',
      description: '',
      price: '',
      quantity: '',
      seller: '',
      location: '',
    });
    setTranscript('');
    setProcessingMessage('');
  };

  const handleLanguageChange = (value: string) => {
    setSelectedLanguage(value);
    setDetectedLanguage(value);
  };

  const labels = SUPPORTED_LANGUAGES.find(lang => lang.code === detectedLanguage)?.labelText || 
                SUPPORTED_LANGUAGES[0].labelText;

  return (
    <div className="container mx-auto py-8">
      <Card className="w-full max-w-2xl mx-auto bg-secondary shadow-lg">
        <CardHeader className="bg-secondary/30 rounded-t-lg">
          <div className="flex justify-end mb-4">
            <Select value={selectedLanguage} onValueChange={handleLanguageChange}>
              <SelectTrigger className="w-[180px] border-[#5C7D2B]">
                <Languages className="w-4 h-4 mr-2" />
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="en-US">English</SelectItem>
                <SelectItem value="hi-IN">हिन्दी</SelectItem>
                <SelectItem value="bn-IN">বাংলা</SelectItem>
                <SelectItem value="te-IN">తెలుగు</SelectItem>
                <SelectItem value="mr-IN">मरा��ी</SelectItem>
                <SelectItem value="ta-IN">தமிழ்</SelectItem>
                <SelectItem value="pa-IN">ਪੰਜਾਬੀ</SelectItem>
                <SelectItem value="gu-IN">ગુજરાતી</SelectItem>
                <SelectItem value="kn-IN">ಕನ್ನಡ</SelectItem>
                <SelectItem value="or-IN">ଓଡ଼ିଆ</SelectItem>
                <SelectItem value="ml-IN">മലയാളം</SelectItem>
                <SelectItem value="ur-IN">اردو</SelectItem>
                <SelectItem value="as-IN">অসমীয়া</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <CardTitle className="text-center">
            <span className="text-3xl font-bold block" style={{ color: '#4A5043' }}>
              S.A.A.T.H.I
            </span>
            <span className="block text-sm font-normal mt-2" style={{ color: '#4A5043' }}>
              {selectedLanguage === 'hi-IN' ? 'स्मार्ट कृषि सहायक तकनीक-आधारित मानव बुद्धिमत्ता' :
               selectedLanguage === 'bn-IN' ? 'স্মার্ট কৃষি সহকারী প্রযুক্তি-ভিত্তিক মানব বুদ্ধিমত্তা' :
               'Smart Agricultural Assistant with Tech-based Human Intelligence'}
            </span>
          </CardTitle>
          <div className="flex justify-center mt-2">
            <p className="text-sm text-muted-foreground">
              {SUPPORTED_LANGUAGES.find(lang => lang.code === selectedLanguage)?.labelText.speak}
            </p>
          </div>
        </CardHeader>
        
        <CardContent className="bg-primary/5">
          <VoiceRecognitionButton
            isListening={isListening}
            isModelLoading={isModelLoading}
            onStartListening={startListening}
            onStopListening={stopListening}
          />
          
          {isListening && (
            <div className="flex justify-center mb-4">
              <div className="flex items-center space-x-1">
                <Volume className="h-4 w-4 animate-bounce text-primary" />
                <Volume2 className="h-5 w-5 animate-bounce text-primary" style={{ animationDelay: '0.2s' }} />
                <Volume className="h-4 w-4 animate-bounce text-primary" style={{ animationDelay: '0.4s' }} />
              </div>
            </div>
          )}
          
          {processingMessage && (
            <div className="text-center mb-4 text-sm text-muted-foreground">
              {labels[processingMessage.toLowerCase().replace(/\.{3}/, '') as keyof typeof labels] || processingMessage}
            </div>
          )}
          
          {isModelLoading && (
            <div className="text-center mb-4 text-sm text-muted-foreground">
              {labels.loading}
            </div>
          )}
          
          {transcript && (
            <div className="mb-6 p-3 bg-secondary rounded-md">
              <p className="text-sm font-medium mb-1">{labels.recognized}</p>
              <p className="text-sm">{transcript}</p>
            </div>
          )}
          
          <div id="updated-fields" className="mb-4">
            {Object.entries(formData).some(([key, value]) => value !== '') && (
              <div className="p-3 bg-green-100 dark:bg-green-900/20 rounded-md">
                <p className="text-sm font-medium mb-2">Updated Fields:</p>
                <div className="space-y-1">
                  {Object.entries(formData).map(([key, value]) => value && (
                    <div key={key} className="text-sm flex items-center gap-2">
                      <span className="font-medium capitalize">{key}:</span>
                      <span className="text-muted-foreground">{value}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
          
          <InputForm
            formData={formData}
            detectedLanguage={detectedLanguage}
            onInputChange={handleInputChange}
            onSubmit={handleSubmit}
            onReset={resetForm}
          />
        </CardContent>
        
        <CardFooter className="bg-secondary/10 flex justify-between p-6 rounded-b-lg">
          <Button 
            onClick={resetForm}
            variant="outline"
            className="border-[#5C7D2B] text-[#5C7D2B] hover:bg-[#5C7D2B] hover:text-white transition-colors"
          >
            {SUPPORTED_LANGUAGES.find(lang => lang.code === selectedLanguage)?.labelText.reset}
          </Button>
          <Button 
            onClick={handleSubmit}
            className="bg-[#5C7D2B] text-white hover:bg-[#4A5D21]"
          >
            {SUPPORTED_LANGUAGES.find(lang => lang.code === selectedLanguage)?.labelText.submit}
          </Button>
        </CardFooter>
      </Card>
    </div>
  );
};

export default SAATHI;
