
import React from 'react';
import { cn } from "@/lib/utils";

interface AnimatedPulseProps {
  isActive: boolean;
  className?: string;
}

const AnimatedPulse: React.FC<AnimatedPulseProps> = ({ 
  isActive, 
  className 
}) => {
  if (!isActive) return null;
  
  return (
    <div className={cn("absolute inset-0 flex items-center justify-center", className)}>
      {/* Outer glow layers */}
      <div className="absolute w-20 h-20 rounded-full bg-gradient-to-r from-[#e8ede4]/20 to-[#e8ede4]/20 animate-pulse blur-xl" />
      <div className="absolute w-16 h-16 rounded-full bg-gradient-to-r from-[#e8ede4]/30 to-[#e8ede4]/30 animate-pulse blur-lg" />
      
      {/* Inner pulse rings */}
      <div className="absolute w-14 h-14 rounded-full opacity-60 animate-ping bg-[#e8ede4]/20" style={{ animationDuration: '3s' }} />
      <div className="absolute w-12 h-12 rounded-full opacity-50 animate-ping bg-[#e8ede4]/30" style={{ animationDuration: '2.5s' }} />
      <div className="absolute w-10 h-10 rounded-full opacity-40 animate-ping bg-[#e8ede4]/40" style={{ animationDuration: '2s' }} />
      
      {/* Core glow */}
      <div className="absolute w-8 h-8 rounded-full bg-gradient-to-r from-[#e8ede4] to-[#e8ede4] opacity-50 blur-sm animate-pulse" />
    </div>
  );
};

export default AnimatedPulse;
