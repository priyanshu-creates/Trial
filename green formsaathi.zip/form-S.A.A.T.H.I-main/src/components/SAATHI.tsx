import React, { useState, useRef, useEffect } from 'react';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Mic, MicOff, Volume, Volume2 } from "lucide-react";
import { pipeline } from "@huggingface/transformers";
import AnimatedPulse from "./AnimatedPulse";
import { useToast } from "@/components/ui/use-toast";

const SUPPORTED_LANGUAGES = [
  { code: 'en-US', name: 'English', labelText: {
    title: "Title",
    description: "Description",
    price: "Price",
    quantity: "Quantity",
    seller: "Seller",
    location: "Location",
    submit: "Submit Form",
    listening: "Listening...",
    processing: "Processing...",
    extracting: "Extracting information...",
    recognized: "Recognized Speech:",
    loading: "Loading speech recognition model...",
    speak: "Speak to fill the form fields automatically",
    formTitle: "Voice Assistant Form",
    detectedLanguage: "Detected language"
  }},
  { code: 'es-ES', name: 'Spanish', labelText: {
    title: "Título",
    description: "Descripción",
    price: "Precio",
    quantity: "Cantidad",
    seller: "Vendedor",
    location: "Ubicación",
    submit: "Enviar Formulario",
    listening: "Escuchando...",
    processing: "Procesando...",
    extracting: "Extrayendo información...",
    recognized: "Voz Reconocida:",
    loading: "Cargando modelo de reconocimiento de voz...",
    speak: "Habla para completar los campos del formulario automáticamente",
    formTitle: "Formulario con Asistente de Voz",
    detectedLanguage: "Idioma detectado"
  }},
  { code: 'fr-FR', name: 'French', labelText: {
    title: "Titre",
    description: "Description",
    price: "Prix",
    quantity: "Quantité",
    seller: "Vendeur",
    location: "Emplacement",
    submit: "Soumettre le Formulaire",
    listening: "Écoute en cours...",
    processing: "Traitement...",
    extracting: "Extraction d'informations...",
    recognized: "Parole Reconnue:",
    loading: "Chargement du modèle de reconnaissance vocale...",
    speak: "Parlez pour remplir automatiquement les champs du formulaire",
    formTitle: "Formulaire avec Assistant Vocal",
    detectedLanguage: "Langue détectée"
  }},
  { code: 'de-DE', name: 'German', labelText: {
    title: "Titel",
    description: "Beschreibung",
    price: "Preis",
    quantity: "Menge",
    seller: "Verkäufer",
    location: "Ort",
    submit: "Formular Absenden",
    listening: "Höre zu...",
    processing: "Verarbeitung...",
    extracting: "Informationen werden extrahiert...",
    recognized: "Erkannte Sprache:",
    loading: "Lade Spracherkennungsmodell...",
    speak: "Sprechen Sie, um die Formularfelder automatisch auszufüllen",
    formTitle: "Formular mit Sprachassistent",
    detectedLanguage: "Erkannte Sprache"
  }},
  { code: 'it-IT', name: 'Italian', labelText: {
    title: "Titolo",
    description: "Descrizione",
    price: "Prezzo",
    quantity: "Quantità",
    seller: "Venditore",
    location: "Posizione",
    submit: "Invia Modulo",
    listening: "In ascolto...",
    processing: "Elaborazione...",
    extracting: "Estrazione informazioni...",
    recognized: "Discorso Riconosciuto:",
    loading: "Caricamento modello di riconoscimento vocale...",
    speak: "Parla per compilare automaticamente i campi del modulo",
    formTitle: "Modulo con Assistente Vocale",
    detectedLanguage: "Lingua rilevata"
  }},
  { code: 'pt-BR', name: 'Portuguese', labelText: {
    title: "Título",
    description: "Descrição",
    price: "Preço",
    quantity: "Quantidade",
    seller: "Vendedor",
    location: "Localização",
    submit: "Enviar Formulário",
    listening: "Ouvindo...",
    processing: "Processando...",
    extracting: "Extraindo informações...",
    recognized: "Fala Reconhecida:",
    loading: "Carregando modelo de reconhecimento de fala...",
    speak: "Fale para preencher automaticamente os campos do formulário",
    formTitle: "Formulário com Assistente de Voz",
    detectedLanguage: "Idioma detectado"
  }},
  { code: 'zh-CN', name: 'Chinese', labelText: {
    title: "标题",
    description: "描述",
    price: "价格",
    quantity: "数量",
    seller: "卖家",
    location: "位置",
    submit: "提交表单",
    listening: "正在听...",
    processing: "处理中...",
    extracting: "提取信息...",
    recognized: "识别的语音:",
    loading: "加载语音识别模型...",
    speak: "说话以自动填写表单字段",
    formTitle: "语音助手表单",
    detectedLanguage: "检测到的语言"
  }},
  { code: 'ja-JP', name: 'Japanese', labelText: {
    title: "タイトル",
    description: "説明",
    price: "価格",
    quantity: "数量",
    seller: "販売者",
    location: "場所",
    submit: "フォームを送信",
    listening: "聞いています...",
    processing: "処理中...",
    extracting: "情報を抽出中...",
    recognized: "認識された音声:",
    loading: "音声認識モデルを読み込んでいます...",
    speak: "話してフォームフィールドを自動的に入力",
    formTitle: "音声アシスタントフォーム",
    detectedLanguage: "検出された言語"
  }},
  { code: 'ru-RU', name: 'Russian', labelText: {
    title: "Заголовок",
    description: "Описание",
    price: "Цена",
    quantity: "Количество",
    seller: "Продавец",
    location: "Местоположение",
    submit: "Отправить Форму",
    listening: "Слушаю...",
    processing: "Обработка...",
    extracting: "Извлечение информации...",
    recognized: "Распознанная Речь:",
    loading: "Загрузка модели распознавания речи...",
    speak: "Говорите для автоматического заполнения полей формы",
    formTitle: "Форма с Голосовым Помощником",
    detectedLanguage: "Обнаруженный язык"
  }},
  { code: 'ar-SA', name: 'Arabic', labelText: {
    title: "العنوان",
    description: "الوصف",
    price: "السعر",
    quantity: "الكمية",
    seller: "البائع",
    location: "الموقع",
    submit: "إرسال النموذج",
    listening: "جاري الاستماع...",
    processing: "جاري المعالجة...",
    extracting: "استخراج المعلومات...",
    recognized: "الكلام المتعرف عليه:",
    loading: "تحميل نموذج التعرف على الكلام...",
    speak: "تحدث لملء حقول النموذج تلقائيًا",
    formTitle: "نموذج المساعد الصوتي",
    detectedLanguage: "اللغة المكتشفة"
  }},
  { 
    code: 'bn-IN', 
    name: 'Bengali', 
    labelText: {
      title: "শিরোনাম",
      description: "বিবরণ",
      price: "মূল্য",
      quantity: "পরিমাণ",
      seller: "বিক্রেতা",
      location: "স্থান",
      submit: "ফর্ম জমা দিন",
      listening: "শুনছি...",
      processing: "প্রক্রিয়াকরণ হচ্ছে...",
      extracting: "তথ্য নিষ্কাশন করা হচ্ছে...",
      recognized: "স্বীকৃত বক্তৃতা:",
      loading: "স্পিচ রিকগনিশন মডেল লোড হচ্ছে...",
      speak: "স্বয়ংক্রিয়ভাবে ফর্ম ফিল্ড পূরণ করতে কথা বলুন",
      formTitle: "ভয়েস সহকারী ফর্ম",
      detectedLanguage: "সনাক্তকৃত ভাষা",
      reset: "রিসেট করুন"
    }
  },
  { 
    code: 'hi-IN', 
    name: 'Hindi', 
    labelText: {
      title: "शीर्षक",
      description: "विवरण",
      price: "कीमत",
      quantity: "मात्रा",
      seller: "विक्रेता",
      location: "स्थान",
      submit: "फॉर्म जमा करें",
      listening: "सुन रहा हूं...",
      processing: "प्रोसेसिंग...",
      extracting: "जानकारी निकाली जा रही है...",
      recognized: "पहचानी गई आवाज़:",
      loading: "स्पीच रिकग्निशन मॉडल लोड हो रहा है...",
      speak: "फॉर्म फील्ड को स्वचालित रूप से भरने के लिए बोलें",
      formTitle: "वॉइस असिस्टेंट फॉर्म",
      detectedLanguage: "पहचानी गई भाषा",
      reset: "रीसेट करें"
    }
  }
];

interface FormData {
  title: string;
  description: string;
  price: string;
  quantity: string;
  seller: string;
  location: string;
}

const SAATHI: React.FC = () => {
  const [isListening, setIsListening] = useState(false);
  const [transcript, setTranscript] = useState('');
  const [detectedLanguage, setDetectedLanguage] = useState('');
  const [processingMessage, setProcessingMessage] = useState('');
  const [formData, setFormData] = useState<FormData>({
    title: '',
    description: '',
    price: '',
    quantity: '',
    seller: '',
    location: '',
  });
  
  const recognitionRef = useRef<SpeechRecognition | null>(null);
  const [isModelLoading, setIsModelLoading] = useState(false);
  const [transcriber, setTranscriber] = useState<any>(null);
  const { toast } = useToast();
  
  useEffect(() => {
    const loadModel = async () => {
      try {
        setIsModelLoading(true);
        const model = await pipeline(
          "automatic-speech-recognition",
          "onnx-community/whisper-tiny",
        );
        setTranscriber(model);
      } catch (error) {
        console.error("Failed to load model:", error);
      } finally {
        setIsModelLoading(false);
      }
    };
    
    loadModel();
  }, []);

  const startListening = () => {
    setIsListening(true);
    setProcessingMessage('Listening...');
    
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    
    if (SpeechRecognition) {
      recognitionRef.current = new SpeechRecognition();
      recognitionRef.current.continuous = true;
      recognitionRef.current.interimResults = true;
      
      recognitionRef.current.lang = ''; 
      
      recognitionRef.current.onstart = () => {
        setIsListening(true);
      };
      
      recognitionRef.current.onresult = (event: SpeechRecognitionEvent) => {
        const currentTranscript = Array.from(event.results)
          .map(result => result[0].transcript)
          .join(' ');
          
        setTranscript(currentTranscript);
        
        for (let i = 0; i < event.results.length; i++) {
          const result = event.results[i];
          
          if (result.lang) {
            console.log("Speech recognition detected language:", result.lang);
            setDetectedLanguage(result.lang);
            break;
          }
        }
      };
      
      recognitionRef.current.onerror = (event: SpeechRecognitionErrorEvent) => {
        console.error('Speech recognition error:', event.error);
        setProcessingMessage('Error: ' + event.error);
        stopListening();
      };
      
      recognitionRef.current.onend = () => {
        if (isListening) {
          processTranscript();
        }
      };
      
      recognitionRef.current.start();
    } else {
      setProcessingMessage('Speech recognition not supported in this browser.');
    }
  };

  const stopListening = () => {
    setIsListening(false);
    
    if (recognitionRef.current) {
      recognitionRef.current.stop();
      setProcessingMessage('Processing...');
      setTimeout(() => processTranscript(), 500);
    }
  };

  const processTranscript = () => {
    setProcessingMessage('Extracting information...');
    
    detectLanguage(transcript)
      .then(() => {
        const extractedData = extractFormData(transcript);
        setFormData(extractedData);
        
        const filledFields = Object.values(extractedData).filter(Boolean).length;
        if (filledFields > 0) {
          const successMessage = detectedLanguage && detectedLanguage.startsWith('en') 
            ? `Successfully extracted ${filledFields} field${filledFields === 1 ? '' : 's'}`
            : detectedLanguage && detectedLanguage.startsWith('es')
              ? `${filledFields} campo${filledFields === 1 ? '' : 's'} extraído${filledFields === 1 ? '' : 's'} con éxito`
              : detectedLanguage && detectedLanguage.startsWith('fr')
                ? `${filledFields} champ${filledFields === 1 ? '' : 's'} extrait${filledFields === 1 ? '' : 's'} avec succès`
                : `Successfully extracted ${filledFields} field${filledFields === 1 ? '' : 's'}`;
          
          toast({
            title: successMessage,
            duration: 3000,
          });
        }
        
        setProcessingMessage('');
      });
  };

  const resetForm = () => {
    setFormData({
      title: '',
      description: '',
      price: '',
      quantity: '',
      seller: '',
      location: '',
    });
    setTranscript('');
    setDetectedLanguage('');
    setProcessingMessage('');
  };

  const detectLanguage = async (text: string) => {
    if (!text || text.trim().length === 0) {
      return;
    }
    
    try {
      const languages = [
        { 
          code: 'en-US', 
          name: 'English',
          words: ['the', 'and', 'is', 'in', 'a', 'to', 'it', 'of', 'for', 'that'],
          patterns: [/ing\b/, /ed\b/, /\'s\b/, /ly\b/],
          alphabet: /[a-zA-Z]/
        },
        { 
          code: 'bn-IN', 
          name: 'Bengali',
          words: ['এবং', 'একটি', 'আছে', 'করা', 'হ���়', 'কি', 'এই', 'সে', 'তার', 'কিন্তু'],
          patterns: [/[\u0980-\u09FF]{2,}/],
          alphabet: /[\u0980-\u09FF]/
        },
        { 
          code: 'hi-IN', 
          name: 'Hindi',
          words: ['और', 'है', 'का', 'की', 'एक', 'में', 'से', 'को', 'पर', 'यह'],
          patterns: [/[\u0900-\u097F]{2,}/],
          alphabet: /[\u0900-\u097F]/
        }
      ];

      const normalizedText = text.toLowerCase();
      
      const scores = languages.map(lang => {
        let score = 0;
        
        const alphabetMatches = normalizedText.match(new RegExp(lang.alphabet.source, 'g'));
        if (alphabetMatches) {
          const alphabetCharCount = alphabetMatches.length;
          const textLength = normalizedText.replace(/\s/g, '').length;
          if (textLength > 0) {
            score += (alphabetCharCount / textLength) * 50;
          }
        }
        
        const words = normalizedText.split(/\s+/);
        words.forEach(word => {
          if (lang.words.includes(word)) {
            score += 10;
          }
        });
        
        lang.patterns.forEach(pattern => {
          const matches = normalizedText.match(pattern);
          if (matches) {
            score += matches.length * 15;
          }
        });
        
        return { code: lang.code, score };
      });
      
      scores.sort((a, b) => b.score - a.score);
      console.log('Language detection scores:', scores);
      
      if (scores.length > 0 && scores[0].score > 20) {
        setDetectedLanguage(scores[0].code);
      } else {
        setDetectedLanguage('en-US');
      }
    } catch (error) {
      console.error('Language detection error:', error);
      setDetectedLanguage('en-US');
    }
  };

  const extractFormData = (text: string): FormData => {
    const newFormData = { ...formData };
    
    const getLanguagePatterns = (langCode: string) => {
      let patterns = {
        title: [
          /(?:title(?:\s+is|\s*:)?\s+)([^,\.]+)/i,
          /(?:name(?:\s+is|\s*:)?\s+)([^,\.]+)/i,
          /([^,\.]{3,30})/
        ],
        description: [
          /(?:description(?:\s+is|\s*:)?\s+)([^,\.]+(?:[,\.][^,\.]+){0,5})/i,
          /(?:about(?:\s+is|\s*:)?\s+)([^,\.]+(?:[,\.][^,\.]+){0,5})/i
        ],
        price: [
          /(?:price(?:\s+is|\s*:)?\s+)([^,\.]+)/i,
          /(?:costs?(?:\s+is|\s*:)?\s+)([^,\.]+)/i,
          /(\$?\d+(?:\.\d{1,2})?)/ 
        ],
        quantity: [
          /(?:quantity(?:\s+is|\s*:)?\s+)(\d+)/i,
          /(?:amount(?:\s+is|\s*:)?\s+)(\d+)/i,
          /(?:\d+)(?:\s+items?|\s+pieces?|\s+units?)?/i
        ],
        seller: [
          /(?:seller(?:\s+is|\s*:)?\s+)([^,\.]+)/i,
          /(?:(?:sold|made|produced)(?:\s+by)?\s+)([^,\.]+)/i,
          /(?:vendor(?:\s+is|\s*:)?\s+)([^,\.]+)/i
        ],
        location: [
          /(?:location(?:\s+is|\s*:)?\s+)([^,\.]+)/i,
          /(?:(?:in|at|from)(?:\s+the)?\s+)([^,\.]+)/i,
          /(?:place(?:\s+is|\s*:)?\s+)([^,\.]+)/i
        ]
      };
      
      if (langCode.startsWith('es')) {
        patterns = {
          title: [
            /(?:título(?:\s+es|\s*:)?\s+)([^,\.]+)/i,
            /(?:nombre(?:\s+es|\s*:)?\s+)([^,\.]+)/i,
            ...patterns.title
          ],
          description: [
            /(?:descripción(?:\s+es|\s*:)?\s+)([^,\.]+(?:[,\.][^,\.]+){0,5})/i,
            /(?:acerca de(?:\s+es|\s*:)?\s+)([^,\.]+(?:[,\.][^,\.]+){0,5})/i,
            ...patterns.description
          ],
          price: [
            /(?:precio(?:\s+es|\s*:)?\s+)([^,\.]+)/i,
            /(?:cuesta(?:\s+es|\s*:)?\s+)([^,\.]+)/i,
            ...patterns.price
          ],
          quantity: [
            /(?:cantidad(?:\s+es|\s*:)?\s+)(\d+)/i,
            ...patterns.quantity
          ],
          seller: [
            /(?:vendedor(?:\s+es|\s*:)?\s+)([^,\.]+)/i,
            /(?:(?:vendido|hecho|producido)(?:\s+por)?\s+)([^,\.]+)/i,
            ...patterns.seller
          ],
          location: [
            /(?:ubicación(?:\s+es|\s*:)?\s+)([^,\.]+)/i,
            /(?:(?:en|de|desde)(?:\s+el|\s+la)?\s+)([^,\.]+)/i,
            ...patterns.location
          ]
        };
      } else if (langCode.startsWith('fr')) {
        patterns = {
          title: [
            /(?:titre(?:\s+est|\s*:)?\s+)([^,\.]+)/i,
            /(?:nom(?:\s+est|\s*:)?\s+)([^,\.]+)/i,
            ...patterns.title
          ],
          description: [
            /(?:description(?:\s+est|\s*:)?\s+)([^,\.]+(?:[,\.][^,\.]+){0,5})/i,
            /(?:à propos(?:\s+est|\s*:)?\s+)([^,\.]+(?:[,\.][^,\.]+){0,5})/i,
            ...patterns.description
          ],
          price: [
            /(?:prix(?:\s+est|\s*:)?\s+)([^,\.]+)/i,
            /(?:coûte(?:\s+est|\s*:)?\s+)([^,\.]+)/i,
            ...patterns.price
          ],
          quantity: [
            /(?:quantité(?:\s+est|\s*:)?\s+)(\d+)/i,
            ...patterns.quantity
          ],
          seller: [
            /(?:vendeur(?:\s+est|\s*:)?\s+)([^,\.]+)/i,
            /(?:(?:vendu|fabriqué|produit)(?:\s+par)?\s+)([^,\.]+)/i,
            ...patterns.seller
          ],
          location: [
            /(?:emplacement(?:\s+est|\s*:)?\s+)([^,\.]+)/i,
            /(?:(?:à|en|de|depuis)(?:\s+le|\s+la)?\s+)([^,\.]+)/i,
            ...patterns.location
          ]
        };
      } else if (langCode.startsWith('de')) {
        patterns = {
          title: [
            /(?:titel(?:\s+ist|\s*:)?\s+)([^,\.]+)/i,
            /(?:name(?:\s+ist|\s*:)?\s+)([^,\.]+)/i,
            ...patterns.title
          ],
          description: [
            /(?:beschreibung(?:\s+ist|\s*:)?\s+)([^,\.]+(?:[,\.][^,\.]+){0,5})/i,
            /(?:über(?:\s+ist|\s*:)?\s+)([^,\.]+(?:[,\.][^,\.]+){0,5})/i,
            ...patterns.description
          ],
          price: [
            /(?:preis(?:\s+ist|\s*:)?\s+)([^,\.]+)/i,
            /(?:kostet(?:\s+ist|\s*:)?\s+)([^,\.]+)/i,
            ...patterns.price
          ],
          quantity: [
            /(?:menge(?:\s+ist|\s*:)?\s+)(\d+)/i,
            /(?:anzahl(?:\s+ist|\s*:)?\s+)(\d+)/i,
            ...patterns.quantity
          ],
          seller: [
            /(?:verkäufer(?:\s+ist|\s*:)?\s+)([^,\.]+)/i,
            /(?:(?:verkauft|hergestellt|produziert)(?:\s+von)?\s+)([^,\.]+)/i,
            ...patterns.seller
          ],
          location: [
            /(?:ort(?:\s+ist|\s*:)?\s+)([^,\.]+)/i,
            /(?:(?:in|bei|aus|von)(?:\s+dem|\s+der)?\s+)([^,\.]+)/i,
            ...patterns.location
          ]
        };
      }
      
      return patterns;
    };
    
    const patterns = getLanguagePatterns(detectedLanguage);
    
    for (const pattern of patterns.title) {
      const match = text.match(pattern);
      if (match && match[1]) {
        newFormData.title = match[1].trim();
        break;
      }
    }
    
    for (const pattern of patterns.description) {
      const match = text.match(pattern);
      if (match && match[1]) {
        newFormData.description = match[1].trim();
        break;
      }
    }
    
    for (const pattern of patterns.price) {
      const match = text.match(pattern);
      if (match && match[1]) {
        newFormData.price = match[1].trim();
        break;
      }
    }
    
    for (const pattern of patterns.quantity) {
      const match = text.match(pattern);
      if (match && match[1]) {
        newFormData.quantity = match[1].trim();
        break;
      }
    }
    
    for (const pattern of patterns.seller) {
      const match = text.match(pattern);
      if (match && match[1]) {
        newFormData.seller = match[1].trim();
        break;
      }
    }
    
    for (const pattern of patterns.location) {
      const match = text.match(pattern);
      if (match && match[1]) {
        newFormData.location = match[1].trim();
        break;
      }
    }
    
    if (!newFormData.title && text.length > 5) {
      const firstSentence = text.split(/[.!?]/)[0];
      if (firstSentence && firstSentence.length < 50) {
        newFormData.title = firstSentence.trim();
      }
    }
    
    return newFormData;
  };

  const handleInputChange = (field: keyof FormData, value: string) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };
  
  const handleSubmit = () => {
    const successMessage = detectedLanguage && detectedLanguage.startsWith('en') 
      ? "Form submitted successfully!"
      : detectedLanguage && detectedLanguage.startsWith('es')
        ? "¡Formulario enviado con éxito!"
        : detectedLanguage && detectedLanguage.startsWith('fr')
          ? "Formulaire soumis avec succès!"
          : "Form submitted successfully!";
          
    toast({
      title: successMessage,
      duration: 3000,
    });
  };

  return (
    <div className="container mx-auto py-8">
      <Card className="w-full max-w-2xl mx-auto bg-secondary shadow-lg">
        <CardHeader className="bg-secondary/30 rounded-t-lg">
          <CardTitle className="text-center">
            <span className="text-3xl font-bold block" style={{ color: '#4A5043' }}>
              S.A.A.T.H.I
            </span>
            <span className="block text-sm font-normal mt-2" style={{ color: '#4A5043' }}>
              Smart Agricultural Assistant with Tech-based Human Intelligence
            </span>
          </CardTitle>
          {detectedLanguage && (
            <div className="flex justify-center items-center gap-2 mt-4 text-sm">
              <span className="text-muted-foreground">Detected Language:</span>
              <span className="font-medium">
                {SUPPORTED_LANGUAGES.find(lang => lang.code === detectedLanguage)?.name || detectedLanguage}
              </span>
            </div>
          )}
          <div className="flex justify-center mt-2">
            <p className="text-sm text-muted-foreground">
              {detectedLanguage ? (
                SUPPORTED_LANGUAGES.find(lang => lang.code === detectedLanguage)?.labelText.speak || 
                "Speak to fill the form fields automatically"
              ) : (
                "Speak to fill the form fields automatically"
              )}
            </p>
          </div>
        </CardHeader>
        
        <CardContent className="bg-primary/5">
          <div className="mb-6 flex justify-center relative">
            <AnimatedPulse isActive={isListening} />
            <Button 
              onClick={isListening ? stopListening : startListening}
              disabled={isModelLoading}
              variant={isListening ? "destructive" : "default"}
              size="lg"
              className={`rounded-full w-16 h-16 flex items-center justify-center transition-all z-10 ${isListening ? 'shadow-lg shadow-primary/25' : ''}`}
              style={{ backgroundColor: '#6B8E23' }}
            >
              {isListening ? 
                <MicOff size={24} style={{ color: '#FFFFFF' }} /> : 
                <Mic size={24} style={{ color: '#FFFFFF' }} />
              }
            </Button>
          </div>
          
          {isListening && (
            <div className="flex justify-center mb-4">
              <div className="flex items-center space-x-1">
                <Volume className="h-4 w-4 animate-bounce text-primary" />
                <Volume2 className="h-5 w-5 animate-bounce text-primary" style={{ animationDelay: '0.2s' }} />
                <Volume className="h-4 w-4 animate-bounce text-primary" style={{ animationDelay: '0.4s' }} />
              </div>
            </div>
          )}
          
          {processingMessage && (
            <div className="text-center mb-4 text-sm text-muted-foreground">
              {detectedLanguage ? (
                SUPPORTED_LANGUAGES.find(lang => lang.code === detectedLanguage)?.labelText[
                  processingMessage === "Listening..." ? "listening" : 
                  processingMessage === "Processing..." ? "processing" : 
                  processingMessage === "Extracting information..." ? "extracting" : 
                  "processing"
                ] || processingMessage
              ) : (
                processingMessage
              )}
            </div>
          )}
          
          {isModelLoading && (
            <div className="text-center mb-4 text-sm text-muted-foreground">
              {detectedLanguage ? (
                SUPPORTED_LANGUAGES.find(lang => lang.code === detectedLanguage)?.labelText.loading || 
                "Loading speech recognition model..."
              ) : (
                "Loading speech recognition model..."
              )}
            </div>
          )}
          
          {transcript && (
            <div className="mb-6 p-3 bg-secondary rounded-md">
              <p className="text-sm font-medium mb-1">
                {detectedLanguage ? (
                  SUPPORTED_LANGUAGES.find(lang => lang.code === detectedLanguage)?.labelText.recognized || 
                  "Recognized Speech:"
                ) : (
                  "Recognized Speech:"
                )}
              </p>
              <p className="text-sm">{transcript}</p>
            </div>
          )}
          
          <div className="space-y-4">
            <div className="grid gap-2">
              <Label htmlFor="title" style={{ color: '#4A5043' }}>
                {detectedLanguage ? (
                  SUPPORTED_LANGUAGES.find(lang => lang.code === detectedLanguage)?.labelText.title || 
                  "Title"
                ) : (
                  "Title"
                )}
              </Label>
              <Input
                id="title"
                value={formData.title}
                onChange={(e) => handleInputChange('title', e.target.value)}
                placeholder={detectedLanguage && detectedLanguage.startsWith('es') ? "Ingrese el título" : "Enter title"}
                style={{ color: '#4A5043' }}
              />
            </div>
            
            <div className="grid gap-2">
              <Label htmlFor="description" style={{ color: '#4A5043' }}>
                {detectedLanguage ? (
                  SUPPORTED_LANGUAGES.find(lang => lang.code === detectedLanguage)?.labelText.description || 
                  "Description"
                ) : (
                  "Description"
                )}
              </Label>
              <Textarea
                id="description"
                value={formData.description}
                onChange={(e) => handleInputChange('description', e.target.value)}
                placeholder={detectedLanguage && detectedLanguage.startsWith('es') ? "Ingrese la descripción" : "Enter description"}
                className="min-h-[100px]"
                style={{ color: '#4A5043' }}
              />
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="grid gap-2">
                <Label htmlFor="price" style={{ color: '#4A5043' }}>
                  {detectedLanguage ? (
                    SUPPORTED_LANGUAGES.find(lang => lang.code === detectedLanguage)?.labelText.price || 
                    "Price"
                  ) : (
                    "Price"
                  )}
                </Label>
                <Input
                  id="price"
                  value={formData.price}
                  onChange={(e) => handleInputChange('price', e.target.value)}
                  placeholder={detectedLanguage && detectedLanguage.startsWith('es') ? "Ingrese el precio" : "Enter price"}
                  style={{ color: '#4A5043' }}
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="quantity" style={{ color: '#4A5043' }}>
                  {detectedLanguage ? (
                    SUPPORTED_LANGUAGES.find(lang => lang.code === detectedLanguage)?.labelText.quantity || 
                    "Quantity"
                  ) : (
                    "Quantity"
                  )}
                </Label>
                <Input
                  id="quantity"
                  value={formData.quantity}
                  onChange={(e) => handleInputChange('quantity', e.target.value)}
                  placeholder={detectedLanguage && detectedLanguage.startsWith('es') ? "Ingrese la cantidad" : "Enter quantity"}
                  style={{ color: '#4A5043' }}
                />
              </div>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="grid gap-2">
                <Label htmlFor="seller" style={{ color: '#4A5043' }}>
                  {detectedLanguage ? (
                    SUPPORTED_LANGUAGES.find(lang => lang.code === detectedLanguage)?.labelText.seller || 
                    "Seller"
                  ) : (
                    "Seller"
                  )}
                </Label>
                <Input
                  id="seller"
                  value={formData.seller}
                  onChange={(e) => handleInputChange('seller', e.target.value)}
                  placeholder={detectedLanguage && detectedLanguage.startsWith('es') ? "Ingrese el vendedor" : "Enter seller"}
                  style={{ color: '#4A5043' }}
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="location" style={{ color: '#4A5043' }}>
                  {detectedLanguage ? (
                    SUPPORTED_LANGUAGES.find(lang => lang.code === detectedLanguage)?.labelText.location || 
                    "Location"
                  ) : (
                    "Location"
                  )}
                </Label>
                <Input
                  id="location"
                  value={formData.location}
                  onChange={(e) => handleInputChange('location', e.target.value)}
                  placeholder={detectedLanguage && detectedLanguage.startsWith('es') ? "Ingrese la ubicación" : "Enter location"}
                  style={{ color: '#4A5043' }}
                />
              </div>
            </div>
            
            {detectedLanguage && (
              <div className="flex items-center gap-2 mt-2 px-2 py-1 bg-secondary/20 rounded-md">
                <span className="text-xs font-medium text-[#4A5043]">
                  {SUPPORTED_LANGUAGES.find(lang => lang.code === detectedLanguage)?.labelText.detectedLanguage || "Detected language"}:
                </span>
                <span className="text-xs font-bold text-[#4A5043]">
                  {SUPPORTED_LANGUAGES.find(lang => lang.code === detectedLanguage)?.name || detectedLanguage}
                </span>
              </div>
            )}
          </div>
        </CardContent>
        
        <CardFooter className="bg-secondary/10 flex justify-between p-6 rounded-b-lg">
          <Button 
            onClick={resetForm}
            variant="outline"
            className="border-[#5C7D2B] text-[#5C7D2B] hover:bg-[#5C7D2B] hover:text-white transition-colors"
          >
            Reset
          </Button>
          <Button 
            onClick={handleSubmit}
            className="bg-[#5C7D2B] text-white hover:bg-[#4A5D21]"
          >
            {detectedLanguage ? (
              SUPPORTED_LANGUAGES.find(lang => lang.code === detectedLanguage)?.labelText.submit || 
              "Submit Form"
            ) : (
              "Submit Form"
            )}
          </Button>
        </CardFooter>
      </Card>
    </div>
  );
};

export default SAATHI;
