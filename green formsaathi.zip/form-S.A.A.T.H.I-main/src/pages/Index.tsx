
import SAATHI from "@/components/saathi/SAATHI";

const Index = () => {
  return <SAATHI />;
};

export default Index;
