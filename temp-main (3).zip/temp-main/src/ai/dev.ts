

import '@/ai/flows/detect-and-respond.ts'; // Add the new flow
import '@/ai/flows/transcribe-and-respond.ts'; // Keep the voice flow
// Remove import: import '@/ai/flows/generate-speech.ts'; // Import the new TTS flow
import '@/ai/flows/tools/search.ts'; // Import the search tool


