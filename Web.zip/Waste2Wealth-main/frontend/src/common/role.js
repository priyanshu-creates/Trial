const ROLE ={
    ADMIN : "ADMIN",
    FARMER : "FARMER"
}

export default ROLE